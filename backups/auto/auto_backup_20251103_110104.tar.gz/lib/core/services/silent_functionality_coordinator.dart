import 'package:flutter/material.dart';
import 'package:flutter/services.dart'; // Point 21: Para MethodChannel
import '../../notifications/notification_service.dart';
import '../../quick_actions/quick_actions_service.dart';
import '../../widgets/status_selector_overlay.dart';
import '../../features/circle/domain_old/entities/user_status.dart';
import 'status_modal_service.dart';

/// Coordinador de funcionalidad silenciosa - Integra sin romper lo existente
class SilentFunctionalityCoordinator {
  static bool _isInitialized = false;
  static BuildContext? _context;

  /// Inicializa SOLO los servicios base (sin BuildContext)
  /// Se debe llamar en main() ANTES de runApp()
  static Future<void> initializeServices() async {
    print('');
    print('=== SILENT COORDINATOR INITIALIZE SERVICES CALLED ===');
    print('[SilentCoordinator] 🚀 INICIO initializeServices() - _isInitialized: $_isInitialized');
    if (_isInitialized) {
      print('[SilentCoordinator] ⚠️ Ya está inicializado, saliendo...');
      return;
    }
    
    try {
      // 1. Inicializar servicios existentes (sin romper nada)
      print('[SilentCoordinator] 🔧 Inicializando servicios base...');
      
      await NotificationService.initialize();
      await QuickActionsService.initialize();
      
      // Point 15: Inicializar servicio del modal transparente
      await StatusModalService.initialize();
      
      // 2. Configurar el handler para la notificación persistente
      NotificationService.setQuickActionTapHandler(_handleQuickActionTap);
      
      // 3. NO mostrar notificación aún - esperar login
      // await NotificationService.showQuickActionNotification();
      
      _isInitialized = true;
      print('[SilentCoordinator] ✅ Servicios base inicializados exitosamente');
      
    } catch (e) {
      print('[SilentCoordinator] ❌ Error inicializando servicios: $e');
      rethrow;
    }
  }

  /// Inicializa toda la funcionalidad silenciosa con BuildContext
  /// DEPRECADO: Usar initializeServices() en main() + setContext() después
  static Future<void> initialize(BuildContext context) async {
    print('[SilentCoordinator] ⚠️ initialize() con BuildContext es deprecado');
    _context = context;
    
    if (!_isInitialized) {
      await initializeServices();
    }
  }

  /// Activa la funcionalidad silenciosa DESPUÉS del login exitoso
  static Future<void> activateAfterLogin() async {
    print('');
    print('=== ACTIVATE AFTER LOGIN CALLED ===');
    print('[SilentCoordinator] 🔓 MÉTODO activateAfterLogin() EJECUTÁNDOSE');
    
    if (!_isInitialized) {
      print('[SilentCoordinator] ❌ ERROR: Servicios NO inicializados');
      print('[SilentCoordinator] ❌ Debes llamar initializeServices() en main() antes de runApp()');
      return;
    }
    
    try {
      print('[SilentCoordinator] 🔓 Usuario autenticado - Activando notificación persistente');
      
      // Mostrar notificación persistente ahora que el usuario está logueado
      await NotificationService.showQuickActionNotification();
      
      print('[SilentCoordinator] ✅ Funcionalidad silenciosa ACTIVADA después del login');
      
    } catch (e) {
      print('[SilentCoordinator] ❌ Error activando después del login: $e');
    }
  }

  /// Desactiva la funcionalidad silenciosa DESPUÉS del logout
  static Future<void> deactivateAfterLogout() async {
    print('');
    print('=== DEACTIVATE AFTER LOGOUT CALLED ===');
    print('[SilentCoordinator] 🔒 MÉTODO deactivateAfterLogout() EJECUTÁNDOSE');
    
    try {
      // Point 21: Limpieza exhaustiva de TODAS las notificaciones
      print('[SilentCoordinator] 🔒 Usuario deslogueado - Limpieza completa iniciada');
      
      // 1. Cancelar la notificación persistente de Quick Actions
      print('[SilentCoordinator] 1/3 Cancelando notificación persistente...');
      await NotificationService.cancelQuickActionNotification();
      
      // 2. Cancelar TODAS las notificaciones del sistema
      print('[SilentCoordinator] 2/3 Cancelando TODAS las notificaciones...');
      await NotificationService.cancelAll();
      
      // 3. Detener KeepAliveService (Point 21: CRÍTICO)
      print('[SilentCoordinator] 3/3 Deteniendo KeepAliveService...');
      try {
        const keepAliveChannel = MethodChannel('zync/keep_alive');
        await keepAliveChannel.invokeMethod('stop');
        print('[SilentCoordinator] ✅ KeepAliveService detenido exitosamente');
      } catch (e) {
        print('[SilentCoordinator] ⚠️ No se pudo detener KeepAliveService: $e');
      }
      
      print('[SilentCoordinator] ✅ Funcionalidad silenciosa DESACTIVADA completamente');
      
    } catch (e) {
      print('[SilentCoordinator] ❌ Error desactivando después del logout: $e');
    }
  }

  static void _handleQuickActionTap() {
    print('[SilentCoordinator] 🎯 Tap en notificación detectado');
    
    if (_context == null || !_isInitialized) {
      print('[SilentCoordinator] ❌ Context no disponible o no inicializado');
      print('[SilentCoordinator] ❌ _context: $_context, _isInitialized: $_isInitialized');
      return;
    }

    if (!_context!.mounted) {
      print('[SilentCoordinator] ❌ Context no está mounted, buscando context válido...');
      return;
    }

    print('[SilentCoordinator] ✅ Abriendo modal de selección de estado');
    Navigator.of(_context!).push(
      PageRouteBuilder(
        opaque: false, // Permite transparencia
        pageBuilder: (context, animation, secondaryAnimation) {
          return StatusSelectorOverlay(
            onClose: () {
              print('[SilentCoordinator] Modal cerrado por usuario');
            },
          );
        },
      ),
    ).catchError((error) {
        print('[SilentCoordinator] ❌ Error al mostrar overlay');
        return null;
    });
  }

  /// Actualiza el contexto desde fuera del coordinador
  static void updateContext(BuildContext context) {
    _context = context;
  }

  /// Actualiza la notificación persistente cuando cambia el status
  static Future<void> updatePersistentNotification(StatusType? currentStatus) async {
    try {
      // Actualizar la notificación con el nuevo estado
      await NotificationService.showQuickActionNotification();
    } catch (e) {
      print('[SilentCoordinator] Error actualizando notificación: $e');
    }
  }

  /// Habilita/deshabilita la funcionalidad silenciosa
  static Future<void> setEnabled(bool enabled) async {
    if (enabled) {
      await NotificationService.showQuickActionNotification();
      await QuickActionsService.setEnabled(true);
    } else {
      await NotificationService.cancelQuickActionNotification();
      await QuickActionsService.setEnabled(false);
    }
  }

  /// Limpia recursos cuando la app se cierra
  static Future<void> dispose() async {
    await NotificationService.cancelQuickActionNotification();
    _isInitialized = false;
    _context = null;
  }
}